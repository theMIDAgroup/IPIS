function c = generate_pseudorandomly_c( ...
    M,     ... % signal dimension
    d_min, ... % minimum distance between two subsequent jumps
    d_max, ... % maximum distance between two subsequent jumps
    a_min, ... % minimum absolute amplitude of jumps
    a_max, ... % maximum absolute amplitude of jumps
    sign_p ... % probability of a (positive) sign of jumps (Bernoulli)
    )

% sample pseudo-randomly all the parameters for defining c
    % positions of jumps (xs)
    xs = round(d_min - 0.5 + (d_max - d_min +1) * rand(1,ceil((M/d_min))));
    xs = cumsum(xs);
    xs = xs(xs<M);
    % absolute amplitudes of jumps (as)
    as = a_min + (a_max - a_min) * rand(1,numel(xs));
    % signs of jumps (signs)
    signs = ones(1,numel(xs));
    signs(rand(1,numel(xs))>sign_p) = -1;
        
% generate c
    % allocate c
    c = zeros(1,M);
    % levels of segments
    S_ls = cumsum(signs .* as);
    for S_i = 1:(numel(S_ls)-1)        
        c( (xs(S_i)+1):(xs(S_i+1)) ) = S_ls(S_i);
    end
    c( (xs(end)+1):M ) = S_ls(end);
end

