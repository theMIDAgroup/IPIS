function x = generate_pseudorandomly_so(...
    TSM,            ... % real M x M orthonormal Trigonometric Synthesis Matrix
    k_min,k_max,    ... % min and max index k of the harmonic components to consider (frequency band) 
    k_n_min,k_n_max ... % min and max number of different indexes k to consider in the band 
    )

% extract signal dimension
M = size(TSM,1);

% compute theoretical upper bound for k
if (mod(M,2) == 0) % M even
    k_tub = M / 2;
else % M odd
    k_tub = (M - 1) / 2;
end

% adjust k_min and k_max
k_min = max(k_min,1); % zero coefficient for 0-th harmonic (zero-mean signal x)
k_max = max(k_max,1); % zero coefficient for 0-th harmonic (zero-mean signal x)
k_min = min(k_min,k_tub);
k_max = min(k_max,k_tub);

% compute theoretical upper bound for k_n
k_n_tub = k_max - k_min + 1;    

% adjust k_n_min and k_n_max
k_n_min = min(k_n_min,k_n_tub);
k_n_max = min(k_n_max,k_n_tub);

% generate the number k_n of harmonics in [k_n_min,k_n_max] (uniformly)
k_n = randi([k_n_min,k_n_max]);

% generate the vector ks of k_n different harmonics in [k_min,k_max] (uniformly)
% sorted for logical mapping of coefficients
ks = sort(randperm(k_max - k_min + 1, k_n) + (k_min - 1));

% select the TSM matrix columns (according to the generated harmonic ks)
if ( (mod(M,2) == 0) && (ks(end) == M/2) )
    % case M even and Nyquist frequency (M/2) selected:
    % the last harmonic k = M/2 has only 1 column (M); others have 2
    temp_ks  = ks(1:(end-1)); % remove Nyquist
    TSM_cols = [2*temp_ks; 2*temp_ks+1]; % interleave alpha_k and beta_k
    TSM_cols = [TSM_cols(:); M];         % linearize and append Nyquist column
else
    % case M odd or (M even and Nyquist not selected):
    % all selected harmonics have 2 columns (2*k and 2*k+1)
    TSM_cols = [2*ks; 2*ks+1];           % interleave alpha_k and beta_k
    TSM_cols = TSM_cols(:);              % linearize
end

% generate the coefficients (uniformly distributed in [-0.5,0.5])
cs = rand(numel(TSM_cols), 1) - 0.5;

% generate the signal x by synthesis (x = TSM * c), using
% selected columns of TSM to match the generated coefficients cs
x = ( TSM(:,TSM_cols) * cs )';

end
