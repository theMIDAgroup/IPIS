function TSM = generate_TSM(M)
%
% Generate an M x M orthonormal trigonometric basis matrix TSM 
% for synthesis of real-valued 1D signals.
%
% This matrix implements a mapping from real Fourier coefficients 
% alpha_k, beta_k to the time-domain real signal x. 
%
% The column vector c of M coefficients is structured as follows:
% If M is odd:
%   c = [alpha_0, alpha_1, beta_1, ..., alpha_kmax, beta_kmax]
% If M is even:
%   c = [alpha_0, alpha_1, beta_1, ..., alpha_kmax, beta_kmax, alpha_{M/2}]
% where kmax = floor((M-1)/2).
%
% The signal x is synthesized by the matrix-vector product:
% x = TSM * c
%
% Input:
%    M:   signal dimension 
% Output:
%    TSM: real M x M orthonormal matrix

% create discrete time indices (0 to M-1)
i = (0:M-1)'; 

% pre-allocate the TSM matrix
TSM = zeros(M,M);

% 1st basis vector (k = 0) for DC (constant) component;
% scale by 1/sqrt(M) to ensure the basis vector have unit-norm.
TSM(:,1) = 1/sqrt(M);

% create/store all harmonic components (cosine and sine pairs) up to k_max;
% scaled by sqrt(2/M) to ensure the basis vectors have unit-norm.
k_max = floor((M-1)/2);
for k = 1:k_max
    % k-th cosine basis vector (associated with coefficient alpha_k)
    TSM(:,2*k)     = sqrt(2/M) * cos(2*pi*k*i/M); 
    % k-th sine basis vector (associated with coefficient beta_k)
    TSM(:,2*k + 1) = sqrt(2/M) * sin(2*pi*k*i/M);
end

% if M is even, we consider the Nyquist component (k = M/2),
% for which only the cosine component exists;
% scaled by 1/sqrt(M) to ensure the basis vector has unit-norm.
if (mod(M,2) == 0)
    TSM(:,M) = 1/sqrt(M) * cos(pi*i); 
end

end