% ----------------------------------------------------------
% PRIN2022 "Inverse Problems in the Imaging Sciences (IPIS)"
% UNIT UNIBO (University of Bologna):
% Serena Morigi, Damiana Lazzaro, Alessandro Lanza
% ----------------------------------------------------------

% Matlab code for generating (for training and/or testing) 
% 1D signals to be used for performing additive decomposition 
% (via variational or data-driven approaches)
%
% written/used for paper (name of variables coherent with notations in the paper): 
% [1] S. Salti, A. Pinto, A. Lanza, S. Morigi, 
%     Additive decomposition of one-dimensional signals using Transformers, 
%     Pattern Recognition Letters, vol.199, pp.239-245, 2026.
%
% also related to paper (in [1] these signals are used to experimentally 
% compare the decomposition results of the proposed data-driven approach 
% with the results obtained using the variational approach in this paper):
% [2] L. Girometti, M. Huska, A. Lanza, S. Morigi, 
%     Convex Predictor–Nonconvex Corrector Optimization Strategy 
%     with Application to Signal Decomposition, 
%     Journal of Optimization Theory and Applications, vol.202, pp.1286-1325, 2024.
%
% This script generates (pseudo-randomly) the four signal components:
% c => piecewise constant component
% s => smooth component
% o => highly oscillatory component
% n => iid zero-mean Generalized Gaussian noise component
% and the (additive) observation:
% f = c + s + o + n 
% with the constraints that:
%     (1) c, s, o, n are all zero-mean (hence, f is also zero-mean)
%     (2) f is unit-norm (Euclidean)
%     (3) n is such that SNR(f,\bar{f}) is prescribed, with \bar{f} = c + s + o

% reset the matlab environment
close all; clear all; clc;

% set the seed of pseudorandom numbers generator, and initialize it
rng_seed = 1;
rng('default');
rng(rng_seed);

% -------------------------------------
% set the parameters for the generation
% -------------------------------------
    
    % ------------------------------
    % flag variables for this script
    VISUALIZE_SIGNALS = 1; % show the signals while generating? 1=>YES; 0=>NO
    SAVE_SIGNALS      = 1; % save a binary Matlab file containing all signals? 1=>YES; 0=>NO
        SAVE_SIGNALS_DIRECTORY = './output/'; % directory where to save
        SAVE_SIGNALS_FILE_NAME = 'signals_05_03_2026'; % name of the file to save
    % ---------------------------
    % size of signals to generate
    M = 256; 
    % -----------------------------
    % number of signals to generate
    N_groups = 10; % number of groups - or component triplets - (\bar{c},\bar{s},\bar{o}) 
    blend_factors = [ 0, 0, 0; % 0 components among c, s, o
                      1, 0, 0; 0, 1, 0; 0, 0, 1; % only 1 component
                      1/2, 1/2, 0; 1/2, 0, 1/2; 0, 1/2, 1/2; % only 2 components (1/2) 
                      1/3, 2/3, 0; 2/3, 1/3, 0; 1/3, 0, 2/3; 2/3, 0, 1/3; 0, 1/3, 2/3; 0, 2/3, 1/3; % only 2 components (1/3,2/3 or 2/3,1/3) 
                      1/3, 1/3, 1/3; % 3 components (1/3) 
                      2/4, 1/4, 1/4; 1/4, 2/4, 1/4; 1/4, 1/4, 2/4]; % 3 components (2/4,1/4,1/4)
    N_blends_per_group = size(blend_factors,1); % number of blending triplets (b_c,b_s,b_o) per group
    N_noise_samples_per_blend = 2;             % number of noise samples n per blending triplet
    N_examples_tot = N_groups * N_blends_per_group * N_noise_samples_per_blend;
    
    % -------------------------------------------------------------------------
    % parameters for pseudo-random generation of the four components c, s, o, n
        
        % --------------------
        % cartoon component c: 
        % distance between subsequent jumps => uniformly distributed
        % absolute amplitude of jumps => uniformly distributed
        % sign of jumps => Bernoulli distributed 
        c_jumps_d_min  = 15;  % minimum distance between two subsequent jumps
        c_jumps_d_max  = 60;  % maximum distance between two subsequent jumps
        c_jumps_a_min  = 0.5; % minimum absolute amplitude of jumps
        c_jumps_a_max  = 1;   % maximum absolute amplitude of jumps
        c_jumps_sign_p = 0.5; % probability of a (positive) sign of jumps (Bernoulli)
        
        % --------------------
        % smooth component s (Fourier)
        s_omega_k_min   = 1; % minimum frequency
        s_omega_k_max   = 6; % maximum frequency
        s_omega_k_n_min = 1; % minimum number of (different) frequencies
        s_omega_k_n_max = 3; % maximum number of (different) frequencies
        
        % --------------------
        % highly oscillatory component o (Fourier)
        o_omega_k_min   = 20; % minimum frequency
        o_omega_k_max   = 50; % maximum frequency
        o_omega_k_n_min = 1;  % minimum number of (different) frequencies
        o_omega_k_n_max = 8;  % maximum number of (different) frequencies
        
        % --------------------
        % noise component n: i.i.d. Generalized Gaussian, with zero-mean,
        % standard deviation set by n_SNR, and shape parameter beta
        n_SNR_min  = 10;
        n_SNR_max  = 20;
        n_beta_min = 2;
        n_beta_max = 2;
    
% for efficiency purposes, generate once for all the M x M real orthonormal 
% matrix TSM (Trigonometric Syntheis Matrix), that will be used to generate 
% both the smooth and oscillatory components (see equations (8)-(9) in [1]).
% The two components are generated by synthesis starting from real Fourier 
% coefficients alpha_k, beta_k, generated randomly, such that the random 
% synthetized signal x is obtained by matrix-vector product x = TSM c, 
% with c the column vector of all the M coefficients
TSM = generate_TSM(M);

% if SAVE_SIGNALS = 1, pre-allocate structures (matrices) where we will store 
% incrementally all the generated examples (c,s,o,n), so that at the end of 
% generation we will save all the structures in a binary Matlab file; note 
% that Fs does not need to be pre-allocated as it will be finally obtained 
% as the sum:
% Fs = Cs + Ss + Os + Ns
if ( SAVE_SIGNALS == 1 )
    Cs = zeros(N_examples_tot,M);
    Ss = zeros(N_examples_tot,M);
    Os = zeros(N_examples_tot,M);
    Ns = zeros(N_examples_tot,M);
end

% print in the command window
fprintf('\nGENERATE 1D SIGNAL DECOMPOSITION EXAMPLES {c,s,t,n,f} (%d GROUPS):\n',N_groups);
% initialize the index of generated examples (c,s,o,n,f)
i_example = 1;
% cycle over all the groups of signals to generate
for i_group = 1:N_groups
    
    % print in the command window
    fprintf('\n    generate signals group %3d/%d ... ',i_group,N_groups);
    
    % generate the three components \bar{c}, \bar{s}, \bar{o},
    % which, we recall, must be standardized (mean 0, norm 1)
    c_bar = generate_pseudorandomly_c( ...
        M,             ... % signal dimension
        c_jumps_d_min, ... % minimum distance between two subsequent jumps
        c_jumps_d_max, ... % maximum distance between two subsequent jumps
        c_jumps_a_min, ... % minimum absolute amplitude of jumps
        c_jumps_a_max, ... % maximum absolute amplitude of jumps
        c_jumps_sign_p ... % probability of a (positive) sign of jumps (Bernoulli)
        );
    s_bar = generate_pseudorandomly_so( ...
        TSM,                            ... % real M x M orthonormal Trigonometric Synthesis Matrix
        s_omega_k_min,s_omega_k_max,    ... % min and max index k of the harmonic components to consider (frequency band) 
        s_omega_k_n_min,s_omega_k_n_max ... % min and max number of different indexes k to consider in the band 
        );
    o_bar = generate_pseudorandomly_so( ...
        TSM,                            ... % real M x M orthonormal Trigonometric Synthesis Matrix
        o_omega_k_min,o_omega_k_max,    ... % min and max index k of the harmonic components to consider (frequency band) 
        o_omega_k_n_min,o_omega_k_n_max ... % min and max number of different indexes k to consider in the band 
        );
    % standardize (mean 0, norm 1)
    c_bar = c_bar - mean(c_bar); s_bar = s_bar - mean(s_bar); o_bar = o_bar - mean(o_bar);
    c_bar_norm = norm(c_bar); s_bar_norm = norm(s_bar); o_bar_norm = norm(o_bar); 
    if ( c_bar_norm > 0 ) 
        c_bar = c_bar / c_bar_norm;
    end
    if ( s_bar_norm > 0 ) 
        s_bar = s_bar / s_bar_norm;
    end
    if ( o_bar_norm > 0 ) 
        o_bar = o_bar / o_bar_norm;
    end
    
    % for the current group, cycle over all the blending factors
    for i_blend = 1:N_blends_per_group        
        % extract the current blending factors triplet (b_c,b_s,b_o)
        bs  = blend_factors(i_blend,:);
        b_c = bs(1); b_s = bs(2); b_o = bs(3);
        % generate the current blended components (c,s,o,f_bar)_blended
        c_blended = b_c * c_bar; % note: mean 0, norm b_c
        s_blended = b_s * s_bar; % note: mean 0, norm b_s
        o_blended = b_o * o_bar; % note: mean 0, norm b_o
        f_bar_blended = c_blended + s_blended + o_blended; % note: mean 0, norm different from 1
        % prepare for generating N_noise_samples_per_blend noise samples
        % Generalized Gaussian with zero-mean, shape parameter n_beta, and norm 
        % (or, equivalently standard deviation) prescribed by n_SNR;
        % to obtain a prescribed n_SNR, we recall that, 
        % from the definition of SNR, we have that the generated n must satisfy:
        % ||n||_2 = || \bar{f} - E[\bar{f}] ||_2 / 10^{n_SNR/20}
            % sample (uniformly) the Generalized Gaussian shape parameter
            n_beta = n_beta_min + (n_beta_max - n_beta_min) * rand(1); 
            % sample (uniformly) the SNR
            n_SNR = n_SNR_min + (n_SNR_max - n_SNR_min) * rand(1); 
            % compute the prescribed n_norm (constant for all samples)
            if ( norm(f_bar_blended) == 0 )
                n_blended_norm = 1;
            else
                n_blended_norm = norm(f_bar_blended) / ( 10^( n_SNR/20 ) );
            end 
            
        % cycle over all the noise samples to generate
        for i_noise_sample = 1:N_noise_samples_per_blend            
            % sample the noise realization n: we use unitary standard deviation
            if ( n_beta <= 5 ) % sample from GG pdf, with mean 0, stdv 1, shape n_beta
                n_blended = generate_GG_sample(...
                    1,M,   ... % height and width of the matrix of generated samples
                    0,     ... % mean               of the Generalized Gaussian distribution
                    1,     ... % standard deviation of the Generalized Gaussian distribution
                    n_beta ... % shape parameter    of the Generalized Gaussian distribution
                    );
            else % sample from uniform pdf, with mean 0, stdv 1 (beta -> +oo)
                n_blended = ( sqrt(3) * 2 ) * (rand(1,M) - 0.5);
            end            
            % normalize n_blended: mean 0, norm equal to 
            % the prescribed n_blended_norm (=> n_SNR)
            if ( norm(n_blended) > 0 )
                n_blended = n_blended - mean(n_blended); 
                n_blended = ( n_blended / norm(n_blended) ) * n_blended_norm;                
            end
            % generate the observation f_blended
            f_blended = f_bar_blended + n_blended; % note: mean 0, but in general norm different from 1
            f_blended_norm = max( norm(f_blended) , 1e-10);
            % we finally normalize f_blended, (dividing by f_blended_norm), 
            % and thus obtaining f: mean 0, norm 1;
            % hence, we have to finally and coherently normalize also 
            % all the components (c,s,o,n)_blended, obtaining (c,s,o,n);
            % doing so, we will finally have that:
            % (1) f = c + s + t + n
            % (2) f  has mean 0, norm 1
            % (3) c, s, o, n  have all mean 0 
            % (4) c, s, o  are blended according to the blending factors b_c, b_s, b_o
            % (5) \bar{f} = c + s + o and n are such that SNR(\bar{f},f) = n_SNR
            f = f_blended / f_blended_norm;
            c = c_blended / f_blended_norm; 
            s = s_blended / f_blended_norm; 
            o = o_blended / f_blended_norm; 
            n = n_blended / f_blended_norm;
            
            % if SAVE_SIGNALS = 1, then store the currently generated
            % example (c,s,o,n) in the pre-allocatd structures; we do 
            % not need to store f = c + s + o + n
            if ( SAVE_SIGNALS == 1 )
                Cs(i_example,:) = c;
                Ss(i_example,:) = s;
                Os(i_example,:) = o;
                Ns(i_example,:) = n;
            end
            
            % if VISUALIZE_SIGNALS = 1, then show the currently generated signals
            if ( VISUALIZE_SIGNALS == 1 )
                figure(1);
                set(gcf,'Position',get(0,'ScreenSize'));
                sgtitle(sprintf('%d-d SIGNALS:   GROUP %3d/%d:   BLEND %2d/%d  [b_c = %.2f , b_s = %.2f , b_o = %.2f]:   NOISE SAMPLE %2d/%d  [beta = %.2f , SNR = %5.2f]',...
                    M,i_group,N_groups,i_blend,N_blends_per_group,b_c,b_s,b_o,i_noise_sample,N_noise_samples_per_blend,n_beta,n_SNR));
                
                subplot(5,1,1)
                f_bar = c + s + o;
                f_min = min(f); f_bar_min = min(f_bar); ff_min = min(f_min,f_bar_min);
                f_max = max(f); f_bar_max = max(f_bar); ff_max = max(f_max,f_bar_max);
                ff_rng = ff_max - ff_min;
                hold off;
                plot(1:M,f_bar,'b'); hold all;
                plot(1:M,f,'r');
                legend('$\bar{f} = c + s + o$','$f = \bar{f} + n$','Interpreter','latex')
                if ( ff_rng > 0 )
                    axis([1,M,ff_min-0.05*ff_rng,ff_max+0.05*ff_rng]);
                else
                    axis tight;
                end
                
                subplot(5,1,2)
                c_min = min(c); c_max = max(c); c_rng = c_max - c_min;
                hold off;
                plot(1:M,c,'b');
                ylabel('c','fontsize',10,'FontWeight','bold');
                if ( c_rng > 0 )
                    axis([1,M,c_min-0.08*c_rng,c_max+0.08*c_rng]);
                else
                    axis tight;
                end
                
                subplot(5,1,3)
                s_min = min(s); s_max = max(s); s_rng = s_max - s_min;
                hold off;
                plot(1:M,s,'b')
                ylabel('s','Rotation',0,'FontWeight','bold','HorizontalAlignment','left');
                if ( s_rng > 0 )
                    axis([1,M,s_min-0.05*s_rng,s_max+0.05*s_rng]);
                else
                    axis tight;
                end
                
                subplot(5,1,4)
                o_min = min(o); o_max = max(o); o_rng = o_max - o_min;
                hold off;
                plot(1:M,o,'b')
                ylabel('o','Rotation',0,'FontWeight','bold','HorizontalAlignment','left');
                if ( o_rng > 0 )
                    axis([1,M,o_min-0.05*o_rng,o_max+0.05*o_rng]);
                else
                    axis tight;
                end
                
                subplot(5,1,5)
                n_min = min(n); n_max = max(n); n_rng = n_max - n_min;
                hold off;
                ylabel('r','Rotation',0,'FontWeight','bold','HorizontalAlignment','left');
                plot(1:M,n,'r')
                if ( n_rng > 0 )
                    axis([1,M,n_min-0.05*n_rng,n_max+0.05*n_rng]);
                else
                    axis tight;
                end
                
                drawnow;
            end
            
            % increment example index
            i_example = i_example + 1;            
        end % end for noise samples
    end % end for blendings
    % print in the command window
    fprintf('DONE.');
end % end for groups

% if SAVE_SIGNALS = 1, then create the structure Fs = Cs + Ss + Os + Ns,
% and finally save on the hard drive a binary Matlab file containing 
% all the five structures Cs, Ss, Os, Ns, Fs
if ( SAVE_SIGNALS == 1 )
    Fs = Cs + Ss + Os + Ns;
    FILE_NAME = sprintf('%s%s.mat',SAVE_SIGNALS_DIRECTORY,SAVE_SIGNALS_FILE_NAME);
    save(FILE_NAME,'Cs','Ss','Os','Ns','Fs'); 
    fprintf('\n\nFILE %s SAVED!\n',FILE_NAME);
else
    fprintf('\n\nNOTHING SAVED (as you set SAVE_SIGNALS = 0)\n');
end



