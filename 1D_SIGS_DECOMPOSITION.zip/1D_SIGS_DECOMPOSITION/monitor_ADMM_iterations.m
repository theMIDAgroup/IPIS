function [monit] = monitor_ADMM_iterations( ...
    monit,           ... structure where monitored quantities are (incrementally) stored
    c,s,o,g,         ... current (iteration k) components
    beta,            ... current (iteration k) ADMM penalty parameter value
    x_delta,z_delta, ... current (iteration k) x and z relative change values
    D,H,             ... matrices                  for computing cost function values
    mu1,mu2,mu3,     ... regularization parameters for computing cost function values
    k,k_max          ... current iteration index and maximum number of iterations to perform
    )

% -----------------------------------------------------------------------
% allocate arrays where storing all iterations-based monitored quantities
if ( k == 0 )
    k_max_plus1 = k_max + 1;
    % values of minimized cost function J = mu1 J_1 + (mu2/2) J_2 + mu3 J_3
    monit.J_1s = zeros(1,k_max_plus1); 
    monit.J_2s = zeros(1,k_max_plus1); 
    monit.J_3s = zeros(1,k_max_plus1);
    % mean values of c, s, o, g and also mid-values of g (g is inside infinity-norm)
    monit.c_ms = zeros(1,k_max_plus1); 
    monit.g_ms = zeros(1,k_max_plus1);
    monit.s_ms = zeros(1,k_max_plus1); 
    monit.o_ms = zeros(1,k_max_plus1); 
    monit.g_mids = zeros(1,k_max_plus1);
    % SNR values of components c, s, o and joint SNR of (c;s;o)
    monit.c_snrs = zeros(1,k_max_plus1); 
    monit.s_snrs = zeros(1,k_max_plus1); 
    monit.o_snrs = zeros(1,k_max_plus1); 
    monit.cso_snrs = zeros(1,k_max_plus1);
    % values of ADMM penalty parameter beta
    monit.betas = zeros(1,k_max_plus1);
    % values of x and z relative changes x_delta and z_delta 
    monit.x_deltas = zeros(1,k_max_plus1); 
    monit.z_deltas = zeros(1,k_max_plus1); 
    % initialize the number of rows printed in the command window: 
    % every 10 rows we print the column header (labels)
    if ( monit.print_along == 1 )
        monit.print_along_rows = 0;
    end
    % store the initial c, s, o components (so that we can show them)
    if ( monit.show_along == 1 )
        monit.c_0 = c; monit.s_0 = s; monit.o_0 = o;
    end
end

% -------------------------------------------------------------------
% compute/store/print/plot/show iterations-based monitored quantities
if ( ( k >= 0 ) && ( k <= k_max ) )
    
    % -------------------------------------------------------
    % compute/store all iterations-based monitored quantities
    k_plus1 = k + 1;
    % compute/store values of minimized cost function J = mu1 J_1 + (mu2/2) J_2 + mu3 J_3
	monit.J_1s(k_plus1) = sum(abs(D*c)); 
    monit.J_2s(k_plus1) = (sum((H*s).^2)) / 2;
    monit.J_3s(k_plus1) = max(abs(g));
    % compute/store mean values of c, s, o, g and also mid-values of g (g is inside infinity-norm)
    monit.c_ms(k_plus1) = mean(c); 
    monit.g_ms(k_plus1) = mean(g); 
    monit.s_ms(k_plus1) = mean(s);    
    monit.o_ms(k_plus1) = mean(o); 
    monit.g_mids(k_plus1) = ( max(g) + min(g) ) / 2;
    % compute/store SNR values of components c, s, o and joint SNR value of (c;s;o)    
    monit.c_snrs(k_plus1) = compute_snr(c,monit.c_GT); 
    monit.s_snrs(k_plus1) = compute_snr(s,monit.s_GT);
    monit.o_snrs(k_plus1) = compute_snr(o,monit.o_GT); 
    monit.cso_snrs(k_plus1) = compute_snr([c;s;o],[monit.c_GT;monit.s_GT;monit.o_GT]);
    % store values of ADMM penalty parameter beta
    monit.betas(k_plus1) = beta;
    % store values of x and z relative changes x_delta and z_delta  
    monit.x_deltas(k_plus1) = x_delta; 
    monit.z_deltas(k_plus1) = z_delta;
    
    % -------------------------------------------------------------------
    % print some of the monitored quantities in the Matlab command window 
    if ( monit.print_along == 1 )
        % check the number of printed rows since the last columns header
        if ( ( k == 0 ) || ( monit.print_along_rows == 15 ) )
            monit.print_along_rows = 1;
            fprintf('\n%5s-|-%5s-|-%9s-|-%8s-|-%6s-|-%6s-|-%6s-|-%6s',...
                '-----','-----','---------','--------','------','------','------','------'); 
            fprintf('\n%-5s | %-5s | %-9s | %-8s | %6s | %6s | %6s | %6s',...
                '  k','beta',' delta_x','   J','SNR(c)','SNR(s)','SNR(o)','SNRcso');
            fprintf('\n%5s-|-%5s-|-%9s-|-%8s-|-%6s-|-%6s-|-%6s-|-%6s',...
                '-----','-----','---------','--------','------','------','------','------');  
        else
            monit.print_along_rows = monit.print_along_rows + 1;
        end
        % compute the total cost function value
        J = mu1 * monit.J_1s(k_plus1) + (mu2/2) * monit.J_2s(k_plus1) + mu3 * monit.J_3s(k_plus1);
        % print the current monitored quantities
        fprintf('\n%05d | %5.3f | %9.3e | %8.6f | %6.3f | %6.3f | %6.3f | %6.3f',...
            k,monit.betas(k_plus1),monit.x_deltas(k_plus1),J,...
            monit.c_snrs(k_plus1),monit.s_snrs(k_plus1),...
            monit.o_snrs(k_plus1),monit.cso_snrs(k_plus1));
    end 
    
    % -------------------------------------------------------------
    % show the currently (iteration k) estimated components c, s, o 
    if ( ( monit.show_along == 1 ) && ( mod(k,10) == 0 ) )
        fig_title = sprintf('ADMM ITERATIONS :   k = %05d :   [ SNR(c) , SNR(s) , SNR(o) , SNR([c;s;o]) ]  =  [ %7.3f , %7.3f , %7.3f , %7.3f ]',...
            k,monit.c_snrs(k+1),monit.s_snrs(k+1),monit.o_snrs(k+1),monit.cso_snrs(k+1));
        show_cso_decomposition( ...
            c,s,o, ... % estimated components
            monit.c_GT,monit.s_GT,monit.o_GT, ... % ground truth components
            50,              ... % number of the created Matlab figure
            fig_title,      ... % top/main title of the figure (sgtitle)
            1, ... % flag variable (0=>NO,1=>YES): show the figure full-screen
            'r', ... % string specifying the line color and type for hat plots
            'b', ... % string specifying the line color and type for GT plots
            'r', ... % string specifying the line color and type for the observation f
            1,   ... % flag variable (0=>NO,1=>YES): show the hat plots
            1,   ... % flag variable (0=>NO,1=>YES): show the GT plots
            1    ... % flag variable (0=>NO,1=>YES): show the observation f in the top subplot
            );
    end
    
    % ----------------------------------------------------------------------
    % plot the graphs of all the monitored quantities in two Matlab figures:
    % figure 51: 1st row:  mean values of c, s, o, g
    %            2nd row:  values of beta, relative changes and mid-values of g
    % figure 52: 1st row:  cost function values      J_1, J_2, J_3, J
    %            2nd row:  SNR values associated to  c,   s,   o,   (c;s;o)
    if ( ( monit.plot_along == 1 ) && ( mod(k,10) == 0 ) && ( k >= 2 ) )
        % pre-compute for efficiency
        ks_plus1 = 1:(k+1);
        % parameters for setting the graphs visualization frame ( axis([...]) )
        graphs_x_min = 0; 
        graphs_x_max = k;
        graphs_y_rng_k_min = 10; 
        graphs_y_rng_low_border_fact = 0.05;
        graphs_y_rng_upp_border_fact = 0.05;
        if ( k < 2 * graphs_y_rng_k_min )
            graph_y_rng_ks = ks_plus1;
        else
            graph_y_rng_ks = graphs_y_rng_k_min:k;
        end
        
        % ----------------------------------------
        % figure 51
        figure(51)
        set(gcf,'Position',get(0,'ScreenSize'))
        
        % mean values of c
        subplot(2,4,1); hold off;
        plot(0:k,monit.c_ms(ks_plus1),'b');
        xlabel('k  (ADMM iteration index)');
        title('$\mathrm{mean}\;\,\mathrm{value}\;\,\mathrm{of}\;\: c^{(k)}$','interpreter','latex','fontsize',12);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.c_ms(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % mean values of s
        subplot(2,4,2); hold off;
        plot(0:k,monit.s_ms(ks_plus1),'k');
        xlabel('k  (ADMM iteration index)');
        title('$\mathrm{mean}\;\,\mathrm{value}\;\,\mathrm{of}\;\: s^{(k)}$','interpreter','latex','fontsize',12);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.s_ms(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % mean values of o
        subplot(2,4,3); hold off;
        plot(0:k,monit.o_ms(ks_plus1),'m');
        xlabel('k  (ADMM iteration index)');
        title('$\mathrm{mean}\;\,\mathrm{value}\;\,\mathrm{of}\;\: o^{(k)}$','interpreter','latex','fontsize',12);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.o_ms(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % mean values of g
        subplot(2,4,4); hold off;
        plot(0:k,monit.g_ms(ks_plus1),'r');
        xlabel('k  (ADMM iteration index)');
        title('$\mathrm{mean}\;\,\mathrm{value}\;\,\mathrm{of}\;\: g^{(k)}$','interpreter','latex','fontsize',12);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.g_ms(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % mid-values of g
        subplot(2,4,8); hold off;
        plot(0:k,monit.g_mids(ks_plus1),'r');
        xlabel('k  (ADMM iteration index)');
        title('$\mathrm{mid-value}\;\,\mathrm{of}\;\: g^{(k)}$','interpreter','latex','fontsize',12);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.g_mids(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % values of beta
        subplot(2,4,5); hold off;
        plot(0:k,monit.betas(ks_plus1),'r');
        xlabel('k  (ADMM iteration index)');
        title('$\mathrm{ADMM}\;\,\mathrm{penalty}\;\,\mathrm{parameter}\;\:\beta^{(k)}$','interpreter','latex','fontsize',12);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.betas(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % values of relative changes for x and z
        subplot(2,4,6); hold off;
        plot(1:k,log10(monit.x_deltas(2:(k+1))),'m',...
             1:k,log10(monit.z_deltas(2:(k+1))),'b');
        xlabel('k  (ADMM iteration index)');
        title('$\mathrm{relative}\;\,\mathrm{change}\;\:\log_{10} \delta_x^{(k)}$','interpreter','latex','fontsize',12);
        legend('$\delta_x^{(k)}$','$\delta_z^{(k)}$','interpreter','latex','fontsize',12);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range([monit.x_deltas(2:(k+1)),monit.z_deltas(2:(k+1))],graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        drawnow;
        
        % ----------------------------------------
        % figure 52
        figure(52)
        set(gcf,'Position',get(0,'ScreenSize'));

        % values of J_1
        subplot(2,4,1); hold off;
        plot(0:k,monit.J_1s(ks_plus1),'b');
        xlabel('k  (ADMM iteration index)');
        title('$J_1^{(k)} := \left\| D c^{(k)} \right\|_1$','interpreter','latex','fontsize',13);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.J_1s(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );

        % values of J_2
        subplot(2,4,2); hold off;
        plot(0:k,monit.J_2s(ks_plus1),'k');
        xlabel('k  (ADMM iteration index)');
        title('$J_2^{(k)} := \left\| H s^{(k)} \right\|_2^2$','interpreter','latex','fontsize',13);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.J_2s(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );

        % values of J_3
        subplot(2,4,3); hold off;
        plot(0:k,monit.J_3s(ks_plus1),'m');
        xlabel('k  (ADMM iteration index)');
        title('$J_3^{(k)} := \left\| g^{(k)} \right\|_{\infty}$','interpreter','latex','fontsize',13);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.J_3s(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );

        % values of J = mu1 J_1 + (m2/2) J_2 + mu3 J_3
        subplot(2,4,4); hold off;
        Js = mu1 * monit.J_1s(ks_plus1) + (mu2/2) * monit.J_2s(ks_plus1) + mu3 * monit.J_3s(ks_plus1);
        plot(0:k,Js(ks_plus1),'r');
        xlabel('k  (ADMM iteration index)');
        title('$J^{(k)} := \mu_1 J_1^{(k)} + (\mu_2/2) J_2^{(k)} + \mu_3 J_3^{(k)}$','interpreter','latex','fontsize',13);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(Js(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );

        % SNR values of c
        subplot(2,4,5); hold off;
        plot(0:k,monit.c_snrs(ks_plus1),'b');
        xlabel('k  (ADMM iteration index)'); 
        title('$\mathrm{SNR}\left(c^{(k)}\right)$','interpreter','latex','fontsize',13);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.c_snrs(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % SNR values of s
        subplot(2,4,6); hold off;
        plot(0:k,monit.s_snrs(ks_plus1),'k');
        xlabel('k  (ADMM iteration index)'); 
        title('$\mathrm{SNR}\left(s^{(k)}\right)$','interpreter','latex','fontsize',13);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.s_snrs(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % SNR values of o
        subplot(2,4,7); hold off;
        plot(0:k,monit.o_snrs(ks_plus1),'m');
        xlabel('k  (ADMM iteration index)'); 
        title('$\mathrm{SNR}\left(o^{(k)}\right)$','interpreter','latex','fontsize',13);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.o_snrs(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );
           
        % SNR values of (c;s;o)
        subplot(2,4,8); hold off;
        plot(0:k,monit.cso_snrs(ks_plus1),'r');
        xlabel('k  (ADMM iteration index)'); 
        title('$\mathrm{SNR}\left(\left[c^{(k)},s^{(k)},o^{(k)}\right]\right)$','interpreter','latex','fontsize',13);
        axis( [graphs_x_min,graphs_x_max, ...
               set_graph_axis_range(monit.cso_snrs(graph_y_rng_ks),graphs_y_rng_low_border_fact,graphs_y_rng_upp_border_fact) ...
               ] );

        drawnow;
    end           
end

end


