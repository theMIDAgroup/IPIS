function axis_range = set_graph_axis_range(xs,low_bord_f,upp_bord_f)
    x_min = min(xs);
    x_max = max(xs);
    x_rng = x_max - x_min;
    x_min = x_min - max(1e-15,low_bord_f * x_rng );
    x_max = x_max + max(1e-15,upp_bord_f * x_rng );
    axis_range = [x_min,x_max];
end

