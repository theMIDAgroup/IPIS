
% load a decomposition example (i.e., the ground truth components c_GT, s_GT, o_GT) 
example_id = 3;
switch example_id
    case 1 % the oscillatory component o_GT is only white noise
        example_file_name = './input/example1.mat';
    case 2 % the oscillatory component o_GT is only auto-correlated "texture"
        example_file_name = './input/example2.mat';
    case 3 % the oscillatory component o_GT is white noise + auto-correlated "texture"
        example_file_name = './input/example3.mat';        
end
load(example_file_name);

% components must be column vectors, so ...
% ... check dimensions and, if necessary, adjust!
[c_GT_h,c_GT_w] = size(c_GT);
[s_GT_h,s_GT_w] = size(s_GT);
[o_GT_h,o_GT_w] = size(o_GT);
if ( c_GT_h == 1 ) 
    c_GT = c_GT';
end
if ( s_GT_h == 1 ) 
    s_GT = s_GT';
end
if ( o_GT_h == 1 ) 
    o_GT = o_GT';
end

% Since, by definition, in the variational model used to perform decomposition 
% (which, we recall, contains a G-norm term of the oscillatory component o), 
% the component o is zero-mean, we remove the mean from the loaded o_GT 
% (which, in general, can be not zero-mean) and we add it back to the piecewise 
% constant component c_GT (we could add it to the smooth component as well), 
% so that the observation f = c_GT + s_GT + o_GT does not change
o_GT_mean = mean(o_GT); o_GT = o_GT - o_GT_mean; c_GT = c_GT + o_GT_mean;

% compute the observation f
f = c_GT + s_GT + o_GT;

% normalize measured signal (and true components)
% by dividing them by the norm of the measure f,
% this should decrease change/scaling of the mus  
% range due to the scale of the measurement range

    % compute the mean of f and remove it from f
    f_mean = mean(f); f = f - f_mean;
    % compute the norm of f and scale it to be unit-norm
    f_norm = norm(f); f = f / f_norm;
    % scale coherently the three ground-truth components
    c_GT = c_GT / f_norm;
    s_GT = s_GT / f_norm;
    o_GT = o_GT / f_norm;

if ( SHOW_GROUND_TRUTH_COMPONENTS == 1 )    
    fig_title = sprintf('GROUND TRUTH COMPONENTS  of  LOADED DECOMPOSITION EXAMPLE  ''%s'' ',example_file_name);
    show_cso_decomposition( ...
        c_GT,s_GT,o_GT, ... % estimated components
        c_GT,s_GT,o_GT, ... % ground truth components
        1,              ... % number of the created Matlab figure
        fig_title,      ... % top/main title of the figure (sgtitle)
        SHOW_GROUND_TRUTH_COMPONENTS_FULL_SCREEN, ... % flag variable (0=>NO,1=>YES): show the figure full-screen
        'r', ... % string specifying the line color and type for hat plots
        'b', ... % string specifying the line color and type for GT plots
        'r', ... % string specifying the line color and type for the observation f
        0,   ... % flag variable (0=>NO,1=>YES): show the hat plots
        1,   ... % flag variable (0=>NO,1=>YES): show the GT plots
        1    ... % flag variable (0=>NO,1=>YES): show the observation f in the top subplot
        );
end

