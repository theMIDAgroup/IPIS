function [ ... 
... % OUTPUT VARIABLES
    c,g,s,o,           ... % estimated (minimized) primal variables (components c,g, then s,o) of the ADMM saddle-point problem
    lambda_1,lambda_2, ... % estimated (maximized) dual   variables (Lagrange multipliers)     of the ADMM saddle-point problem 
    beta,              ... % estimated (if self-adaptive strategy is used) ADMM penalty parameter
    k,x_delta,         ... % ADMM convergence: number of performed iterations and final x relative change
    monit ]            ... % structure where important quantities along ADMM iterations are (possibly) stored
= decompose_1D_sigs_into_cso_by_ADMM( ...
... % INPUT VARIABLES
    f,mu1,mu2,mu3,         ... % model data/parameters: observation and regularization parameters
    c,g,lambda_1,lambda_2, ... % ADMM: initial guesses: primal and dual variables
    beta,                  ... % ADMM: penalty parameter (initial, if self-adaptive strategy is used) 
    beta_self_adapt,       ... % flag variable (0=>NO,1=>YES): use self-adaptive strategy for beta
    k_max,x_delta_tol,     ... % ADMM stopping criteria: max number of iterations and tolerance for x relative change    
    mon_itrs,              ... % flag variable (0=>NO,1=>YES): monitor/store/print/plot important quantities along ADMM iterations 
    mon_itrs_print_along,  ... % flag variable (0=>NO,1=>YES): print some of the monitored quantities in the command window along ADMM iterations
    mon_itrs_plot_along,   ... % flag variable (0=>NO,1=>YES): plot the graphs of all the monitored quantities in the command window along ADMM iterations
    mon_itrs_show_along,   ... % flag variable (0=>NO,1=>YES): show the estimated components c, s, o along the ADMM iterations
    mon_itrs_show_final,   ... % flag variable (0=>NO,1=>YES): show all the monitored quantities (in graphs) at the end of ADMM iterations
    c_GT,s_GT,o_GT         ... % ground truth components (if available), so that we can also monitor SNR of decomposition
    )
%
% By using the (iterative) ADMM-based optimization scheme proposed
% in [1] (Section 5), compute approximate solutions (that is, minimizers) 
% of the convex, linearly constrained TV-TIK-G variational model: 
%
% {c_hat,g_hat} in argmin J(c,g;mu1,mu2,mu3) ,  
%                   c,g
%
% subject to:  sum_i c_i = 0 (c is zero-mean) ,
%
% and with:  J(c,g;mu1,mu2,mu3) =    mu1    || Dc ||_1                + 
%                                 + (mu2/2) || H(c + DT g - f) ||_2^2 +
%                                 +  mu3    || g ||_oo  ,
%
% for the additive decomposition of a given 1D scalar signal f, namely
%
% f = c + s + o,   with c,s,o  cartoon, smooth, oscillatory components.
% 
% The above problem is an equivalent, reduced-dimensionality (2N) version 
% of the original optimization problem with c, s, o, g components as the 
% optimization variables (4N) - see [1]. 
% Note that, given c and g, the components s and o are simply obtained by:
% o = DT g; s = f - c - o;
%
% [1] L. Girometti, M. Huska, A. Lanza, S. Morigi, 
%     Convex Predictor–Nonconvex Corrector Optimization Strategy 
%     with Application to Signal Decomposition, 
%     Journal of Optimization Theory and Applications, vol.202, pp.1286-1325, 2024.


% parameters of the self-adaptive strategy used (if beta_self_adapt = 1) 
% to adapt/update the ADMM penalty parameter beta along iterations
if ( beta_self_adapt == 1 )
    update_beta_every_iters = 1;
    beta_min = 0.000001;
    beta_max = 1000000;
    omega    = 0.5;
end
%beta = 1.8560009;

    
% -------------------------------------------------------------------------
% initialize ADMM algorithm
    
    % initialize iteration index k
    k = 0; 
    
    % -----------------------------------------------------
    % initialize the two primal optimization variables x, z
    x = [ c ; g ]; z = x; z1 = c; z2 = g;
    
    % ------------------------
    % extract signal dimension
    N  = numel(f); % total number of samples
    N2 = N * 2;    % twice the number of samples: used many times along iterations
    
    
    % ---------------------------------------------------------------------
    % given the inputs, for efficiency purposes 
    % compute/store once for all at the beginning (here) all the quantities 
    % that will be used for the solution of the ADMM algorithm sub-problems 
    % but that do not change along the ADMM iterations
    
        % -----------------------------------------------------------------
        % finite difference matrices D and H, both with anti-reflective BCs
            ones_d = ones(N,1);
            % -----
            % D
            D            = spdiags([-ones_d,ones_d],0:1,N,N);
            D(N,(N-1):N) = [-1,1]; % D(N,1) = 1; D(N,N) = -1; D(N,N) = 0;
            % -----
            % H
            H            = spdiags([ones_d,-2*ones_d,ones_d],-1:1,N,N);
            H(1,1:2)     = [0,0]; H(N,(N-1):N) = [0,0];
        % --------------------------------------------------------------
        % sub-problem for the primal variable x = (c;g) (linear system):            
        % create the 2N x 2N s.p.d. sparse coefficient matrix C of the 
        % linear system defined in equation (30) in [1]:
        % C = C_0 + C_1(beta) = QT Q + (beta/mu2) I_2N , 
        % with  Q = [ H , H DT ] => C_0 = [   HT H ,   HT H DT 
        %                                   D HT H , D HT H DT ]
        HTH  = H' * H; DHTH = D * HTH;
        C_0  = [ HTH , DHTH' ; DHTH , D' * HTH * D ];
        C    = C_0 + (beta/mu2) * speye(N2);
        % create constant right-hand side vectors HTHf and DTHTHf
        HTHf  = HTH * f;
        DHTHf = D * HTHf;        
        % sub-problem for the primal variable z1 (TV-l2 denoising)
        % ... nothing to pre-compute!        
        % sub-problem for the primal variable z2 (prox of l_inf)
        % ... nothing to pre-compute!        
        % sub-problem for the dual variables lambda_1 and lambda_2
        % ... nothing to pre-compute!
                    
% -------------------------------------------
% initialize/store/print monitored quantities
if ( mon_itrs == 1 )
    % print a "header" in the Matlab command window 
    if ( mon_itrs_print_along == 1 )
        fprintf('\n----------------------------------------------------------');
        fprintf('\nTV-TIK-G by ADMM (mu1 %7.2f , mu2 %7.2f) ITS-BASED MONITOR:',mu1,mu2);
        fprintf('\n----------------------------------------------------------');
    end
    % initialize structure
    monit.flag = 1;
    monit.print_along = mon_itrs_print_along; 
    monit.plot_along  = mon_itrs_plot_along; 
    monit.show_along  = mon_itrs_show_along; 
    monit.show_final  = mon_itrs_show_final;
    monit.c_GT = c_GT; monit.s_GT = s_GT; monit.o_GT = o_GT;
    % given c, g, compute components s, o
    o = D' * g; s = f - c - o;
    % monitor
    x_delta = 0; z_delta = 0; % no relative change exists for iteration k = 0
    
    monit = monitor_ADMM_iterations( ...
        monit,           ... structure where monitored quantities are (incrementally) stored
        c,s,o,g,         ... current (iteration k) components
        beta,            ... current (iteration k) ADMM penalty parameter value
        x_delta,z_delta, ... current (iteration k) x and z relative change values
        D,H,             ... matrices                  for computing cost function values
        mu1,mu2,mu3,     ... regularization parameters for computing cost function values
        k,k_max          ... current iteration index and maximum number of iterations to perform
        );
else
    monit.flag = -1;
end

% -------------------------------------------------------------------------
% carry out ADMM iterations
% -------------------------------------------------------------------------

% initialize stopping criteria flags
stop_flags = [0,0]; % 0 => don't stop; 1 => stop

% while no stopping criterion is satisfied...iterate
while ( sum(stop_flags) == 0 )
    
    % update iteration index
    k = k + 1;
    
    % -------------------------------------------------------------------------
    % update 1st primal variable x = (c;g) (non-separable s.p.d. linear system)
    % -------------------------------------------------------------------------
        
        % store x_old for future check of 2nd stopping criterion
        x_old = x; 
        % compute the right-hand side of the linear system
        rhs = [ HTHf  + (beta/mu2) * (z1 - lambda_1 / beta) ; ...
                DHTHf + (beta/mu2) * (z2 - lambda_2 / beta) ];
        % compute the new iterate
        x = C \ rhs; c = x(1:N); g = x((N+1):end);
    
    % ------------------------------------------------------------------------
    % update 2nd primal variable z = (z1;z2) (separable minimization in z1,z2)
    % ------------------------------------------------------------------------
        
        % ------------------------------------------------------
        % store z_old for future check of 2nd stopping criterion        
        z_old = z;
        % ----------------------------------------------
        % update z1 (1D TV-l2 denoising, Laurent Condat)
        q = c + lambda_1 / beta;
        z1 = TV1D_denoise_mex( q - mean(q) , (mu1/beta) );        
        % ----------------------------------------------
        % update z2 (prox of l_oo norm, Laurent Condat)
        w     = g + lambda_2 / beta;
        mu3_over_beta = mu3 / beta;
        w_abs = abs(w);
        if ( sum(w_abs) <= mu3_over_beta )
            z2 = zeros(N,1);
        else
            tau = max( (cumsum(sort(w_abs,1,'descend'))-mu3_over_beta)./(1:N)' );
            z2 = max(min(w,tau),-tau);
        end        
        % ------------------------------------------------
        % form the updated 2nd primal variable z = (z1;z2)
        z = [z1;z2];
        
    % ------------------------------------------------------------------------
    % update dual variable lambda = (lambda_1;lambda_2) (dual gradient ascent)
    % ------------------------------------------------------------------------
    lambda_1 = lambda_1 + beta * (c - z1);
    lambda_2 = lambda_2 + beta * (g - z2);
        
    % ---------------------------------------------------------
    % check stopping criteria and update penalty parameter beta
    % --------------------------------------------------------- 
       
        % ------------------------------------------------------
        % compute x relative change (for 2nd stopping criterion)
        x_delta = norm(x - x_old) / norm(x_old);
        
        % ------------------------------------------------------
        % compute z relative change (for 3rd stopping criterion)
        z_delta = norm(z - z_old) / norm(z_old);
        
        % -----------------------------------
        % check 1st and 2nd stopping criteria    
            % 1st: number of performed iterations
            if ( k == k_max ) 
                stop_flags(1) = 1;
            end
            % 2nd: x relative change
            if ( x_delta < x_delta_tol ) 
                stop_flags(2) = 1;
            end
        
        % -------------------------------------
        % self-adapt the ADMM penalty parameter
        if ( beta_self_adapt == 1 )
            if ( mod(k,update_beta_every_iters) == 0 )
                temp = norm( [lambda_1;lambda_2] ) / norm( [z1;z2] );
                beta = (1 - omega) * beta + omega * min(max(temp,beta_min),beta_max);
                %omega = 2^(-k/100);
                % update the beta-dependent part of the coefficient matrix
                % C of the linear system solved in the ADMM x-subproblem
                C = C_0 + (beta/mu2) * speye(N2);                
            end
        end    
    
    % ---------------------------------------------
    % compute/store/print/show monitored quantities
    % ---------------------------------------------
    if ( mon_itrs == 1 )
        % given c, g, compute components s, o
        o = D' * g; s = f - c - o;
        % monitor
        monit = monitor_ADMM_iterations( ...
            monit,           ... structure where monitored quantities are (incrementally) stored
            c,s,o,g,         ... current (iteration k) components
            beta,            ... current (iteration k) ADMM penalty parameter value
            x_delta,z_delta, ... current (iteration k) x and z relative change values
            D,H,             ... matrices                  for computing cost function values
            mu1,mu2,mu3,     ... regularization parameters for computing cost function values
            k,k_max          ... current iteration index and maximum number of iterations to perform
            );      
    end
    
end % end ADMM iterations

% given the estimated c, g components, compute s, o components
o = D' * g; s = f - c - o;

% one of the stopping criteria has been met --> end iterations  
% and, before returning the estimated x = (c;g), the total number 
% of performed ADMM iterations k and the final x relative change 
% x_delta to the main script, show (if mon_itrs = 1) some 
% of the iterations-based monitored quantities



end


