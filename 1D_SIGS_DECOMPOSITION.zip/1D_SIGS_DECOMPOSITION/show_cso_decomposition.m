function [] = show_cso_decomposition( ...
    c_hat,s_hat,o_hat, ... % estimated components
    c_GT,s_GT,o_GT,    ... % ground truth components
    fig_number,        ... % number of the created Matlab figure
    fig_title,         ... % top/main title of the figure (sgtitle)
    fig_full_screen,   ... % flag variable (0=>NO,1=>YES): show the figure full-screen
    linespec_hat,      ... % string specifying the line color and type for hat plots
    linespec_GT,       ... % string specifying the line color and type for GT plots
    linespec_f,        ... % string specifying the line color and type for the observation f
    fig_show_hat,      ... % flag variable (0=>NO,1=>YES): show the hat plots
    fig_show_GT,       ... % flag variable (0=>NO,1=>YES): show the GT plots
    fig_show_f         ... % flag variable (0=>NO,1=>YES): show the observation f in the top subplot
    )
% set legends font size
legs_fs = 11;

% extract signals dimension
N = numel(c_hat);

% manage the fig_show_f choice
if ( fig_show_f == 1 )
    f = c_GT + s_GT + o_GT;
    subplots_grid_n_rows = 4;
else
    subplots_grid_n_rows = 3;
end

% create the figure
figure(fig_number)
if ( fig_full_screen == 1 )
    set(gcf,'Position',get(0,'ScreenSize'));
end
sgtitle(fig_title);

% initialize subplot index
subplot_index = 0;

% subplot for f
if ( fig_show_f == 1 )
    subplot_index = subplot_index + 1;
    subplot(subplots_grid_n_rows,1,subplot_index)
    hold off;
    plot(1:N,f,linespec_f); 
    legend('$f$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(f,0.06,0.06)] );
end

% --------------------------
% subplot for c_hat and c_GT
subplot_index = subplot_index + 1;
subplot(subplots_grid_n_rows,1,subplot_index)
hold off;
if ( ( fig_show_GT == 1 ) && ( fig_show_hat == 1 ) )
    plot(1:N,c_GT,linespec_GT); hold all;
    plot(1:N,c_hat,linespec_hat);
    legend('$c_{\mathrm{GT}}$','$\widehat{c}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(c_GT,0.25,0.25)] );
elseif ( fig_show_GT == 1 )
    plot(1:N,c_GT,linespec_GT);
    legend('$c_{\mathrm{GT}}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(c_GT,0.1,0.1)] );
elseif ( fig_show_hat == 1 )
    plot(1:N,c_hat,linespec_hat);
    legend('$\widehat{c}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(c_hat,0.1,0.1)] );
end

% --------------------------
% subplot for s_hat and s_GT
subplot_index = subplot_index + 1;
subplot(subplots_grid_n_rows,1,subplot_index)
hold off;
if ( ( fig_show_GT == 1 ) && ( fig_show_hat == 1 ) )
    plot(1:N,s_GT,linespec_GT); hold all;
    plot(1:N,s_hat,linespec_hat);
    legend('$s_{\mathrm{GT}}$','$\widehat{s}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(s_GT,0.25,0.25)] );
elseif ( fig_show_GT == 1 )
    plot(1:N,s_GT,linespec_GT);
    legend('$s_{\mathrm{GT}}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(s_GT,0.1,0.1)] );
elseif ( fig_show_hat == 1 )
    plot(1:N,s_hat,linespec_hat);
    legend('$\widehat{s}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(s_hat,0.1,0.1)] );
end

% --------------------------
% subplot for o_hat and o_GT
subplot_index = subplot_index + 1;
subplot(subplots_grid_n_rows,1,subplot_index)
hold off;
if ( ( fig_show_GT == 1 ) && ( fig_show_hat == 1 ) )
    plot(1:N,o_GT,linespec_GT); hold all;
    plot(1:N,o_hat,linespec_hat);
    legend('$o_{\mathrm{GT}}$','$\widehat{o}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(o_GT,0.15,0.15)] );
elseif ( fig_show_GT == 1 )
    plot(1:N,o_GT,linespec_GT);
    legend('$o_{\mathrm{GT}}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(o_GT,0.06,0.06)] );
elseif ( fig_show_hat == 1 )
    plot(1:N,o_hat,linespec_hat);
    legend('$\widehat{o}$','interpreter','latex','fontsize',legs_fs);
    axis( [1,N,set_graph_axis_range(o_hat,0.06,0.06)] );
end

drawnow;

end

