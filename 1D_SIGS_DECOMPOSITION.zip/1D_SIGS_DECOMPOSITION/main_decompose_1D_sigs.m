% -------------------------------------------------------------------------
% PRIN2022 "Inverse Problems in the Imaging Sciences (IPIS)"
% UNIT UNIBO (University of Bologna):
% Serena Morigi, Damiana Lazzaro, Alessandro Lanza
% -------------------------------------------------------------------------

% The first time you run this code on a computer, uncomment the following 
% instruction, so that you mex-compile (once for all) the C-code 
% "TV1D_denoise_mex.c" (which is in the same directory of this script), 
% and you obtain (in the same directory) the C-compiled file 
% "TV1D_denoise_mex.mexw64". This compiled file is used for the 
% efficient solution of one of the minimization sub-problems of
% the ADMM-based numerical solver used in this code. The C-code 
% "TV1D_denoise_mex.c" has been written and made available by L. Condat 
% (and S. Becker). See REMARK (1) below for more details.
% Once you compile successfully the file, comment the instruction below 
% to avoid re-compiling every time you run this script. If you have 
% problems in compiling, change the instruction (add -v option) into:
% mex -v TV1D_denoise_mex.c -largeArrayDims
% In this way, you will perform a "verbose" compiling, so that you will 
% obtain information (debug) on every step of the compiling process.

mex TV1D_denoise_mex.c -largeArrayDims

% -------------------------------------------------------------------------
% INVERSE PROBLEM:
% This Matlab code is aimed to decompose a 1D signal f into
% the sum of three morphologically different components:
%
% f = c + s + o
%
% where
%
% c => piecewise constant component
% s => smooth component (trend)
% o => highly oscillatory component
% 
% The highly oscillatory component can include white (or, more 
% in general, i.i.d) noise signals and/or "texture", i.e. 
% auto-correlated (non-white, colored) mid-high-frequency signals.

% -------------------------------------------------------------------------
% VARIATIONAL MODEL:
% The decomposition is obtained based on the Predictor stage in [1], 
% i.e. on solving the linearly constrained, convex, non-differentiable 
% three-terms variational model oulined in equations (3)-(4) in [1]. 
%
% [1] L. Girometti, M. Huska, A. Lanza, S. Morigi, 
%     Convex Predictor–Nonconvex Corrector Optimization Strategy 
%     with Application to Signal Decomposition, 
%     Journal of Optimization Theory and Applications, vol.202, pp.1286-1325, 2024.
%
% The three terms are suitably designed to capture the different 
% morphologies of the three components c, s, o to separate. The model, 
% when applied to decomposing an observed N-samples 1D signal f reads:
%
% {c_hat,s_hat,o_hat} in argmin J(c,s,o;mu1,mu2,mu3) , 
%                        c,s,o
%
% subject to:  c + s + o = f , sum_i c_i = 0 (c is zero-mean) ,
%
% and with:  J(c,s,o;mu1,mu2,mu3) =    mu1    || Dc ||_1   (TV semi-norm)
%                                   + (mu2/2) || Hs ||_2^2 (TIK norm)
%                                   +  mu3    || o ||_G    (Meyer's G-norm),
%
% with mu1, m2, mu3 > 0 free regularization parameters, D and H two N x N 
% finite difference matrices discretizing the 1st- and 2nd-order derivative 
% operators, respectively. The G-norm reads 
%
% ||o||_G = inf { ||g||_oo | o = DT g } .
%            g
%
% In [1] (Section 4), the model is then equivalently and usefully 
% reformulated (the problem dimensionality decreases from 4N to 2N) as:
%
% {c_hat,g_hat} in argmin_{c,g} J(c,g;mu1,mu2,mu3) , 
%                   c,g
%
% subject to:  sum_i c_i = 0 (c is zero-mean) ,
%
% and with:  J(c,g;mu1,mu2,mu3) =    mu1    || Dc ||_1   
%                                 + (mu2/2) ||H(c + DT g - f)||_2^2
%                                 +  mu3    || g ||_oo ,
%
% Once a solution {c_hat,g_hat} is computed, the associated estimated 
% components s_hat and o_hat are simply obtained applying the formulas:
%
% o_hat = DT g_hat , s_hat = f - c_hat - o_hat .

% -------------------------------------------------------------------------
% NUMERICAL SOLVER:
% The reduced variational model is efficiently solved based on a suitable
% 2-blocks ADMM-based iterative algorithm (see Section 5 in [1]), equipped 
% with an effective self-adaptive strategy for the ADMM penalty parameter, 
% aimed to improve the convergence behaviour.

% -------------------------------------------------------------------------
% IMPORTANT REMARKS:
% (1) In the ADMM-based solver, the mimization sub-problem for the primal 
%     variable z_1 is a 1D TV-l2 denosing problem. For efficiency, and 
%     coherently with what is declared in [1], this problem is solved 
%     exactly in finite-time by means of the O(N) approach proposed by 
%     L. Condat in [2].
%      
%     [2] L. Condat, A direct algorithm for 1-D total variation denoising,
%         IEEE Signal Processing Letters, vol.20(11), pp.1054–1057, 2013.
%
%     In particular, we used the C-implementation of the algorithm made
%     available by the author ( --> https://lcondat.github.io/software.html , 
%     hyperlink "mex" in the sentence "For use in Matlab, mex files made 
%     by Stephen Becker" ). 
% (2) Both in this script and in the function "decompose_1D_sigs_into_cso_by_ADMM", 
%     which implements the ADMM-based solver, the implementation is totally 
%     coherent with [1]: in terms of variational model, of minimization
%     algorithm and of names of variables. The only exception concerns the 
%     regularization parameters: in [1] we have gamma_1 and gamma_2 as the
%     regularization parameters for the c and s terms, while the last term 
%     for variable g is multiplied by 1. In this implementation, we call 
%     the first two parameters mu1 and mu2, and we use also a third
%     parameter mu3 in front of the last term (but we set it equal to 1). 
% (3) To evaluate effectiveness of the variational model modulo the values 
%     of the regularization parameters mu1, mu2, m3, first we fix mu3 to a  
%     constant value (which clearly does not exclude any possible solution 
%     of the model), then we run the model/algorithm for a uniform rectangular 
%     grid of (mu1,m2) values (in logarithmic scale), we collect the SNR 
%     values associated to all the decompositions obtained, and finally 
%     call the "model result" the "best" decomposition achieved, associated 
%     to the highest SNR value.
% (4) Three test decomposition examples are placed (as binary Matlab files 
%     .mat) in the folder "./input/"; one can choose which example to load 
%     and test by setting the variable example_id (= 1,2,3) on the top of 
%     the file "generate_decomposition_example.m", which is called at line 
%     161 of this main script.

% -------------------------------------------------------------------------

% reset the matlab environment
close all; clear all; clc;

% set the seed of pseudorandom numbers generator, and initialize it
rng_seed = 1;
rng('default');
rng(rng_seed);

% --------------------------------------------------
% set flag variables to choose what/how to visualize
    % what
    SHOW_GROUND_TRUTH_COMPONENTS = 1; % figure 1
    SHOW_CURRENT_DECOMPOSITION   = 1; % figure 2
    SHOW_PERFORMANCE_SURFACES    = 1; % figures 3-4
    SHOW_BEST_SNR_DECOMPOSITION  = 1; % figure 5
    % how: figures shown full-screen (1) or not (0)
    SHOW_GROUND_TRUTH_COMPONENTS_FULL_SCREEN = 1;
    SHOW_CURRENT_DECOMPOSITION_FULL_SCREEN   = 1;
    SHOW_PERFORMANCE_SURFACES_FULL_SCREEN    = 1;
    SHOW_BEST_SNR_DECOMPOSITION_FULL_SCREEN  = 1;    

% -----------------------------------------------------------------
% generate (load or create) a decomposition example, i.e. the three 
% ground-truth components c_GT, s_GT, o_GT and the observation f
generate_decomposition_example;

% ----------------------------
% extract dimension of signals
N = numel(f);

% -----------------------------------------------------------------------
% following Remark (3) above, set configurations of mu1, mu2, mu3 to test 
% ----------------
% set the m3 value
mu3 = 1;
% ------------------------------------------------------------------
% set the (mu1,mu2) rectangular search domain, in logarithmic scale: 
% for the three decomposition examples provided (example1,2,3) in 
% the "input" directory, we preliminarly detected the reasonable
% grids reported in the switch-case below (clearly, feel free to change them!).
% If you create new examples, you can add new cases to the switch.
switch example_id 
    case 1 % the oscillatory component o_GT is only white noise
        % mu1
        mu1s_min = 10^(-2.5);
        mu1s_max = 10^(-1);
        mu1s_n   = 7;
        % mu2
        mu2s_min = 10^(3.5);
        mu2s_max = 10^(4.5);
        mu2s_n   = 7; 
    case 2 % the oscillatory component o_GT is only auto-correlated "texture"
        % mu1
        mu1s_min = 10^(-2.2);
        mu1s_max = 10^(-1);
        mu1s_n   = 7;
        % mu2
        mu2s_min = 10^(4);
        mu2s_max = 10^(5);
        mu2s_n   = 7; 
    case 3 % the oscillatory component o_GT is white noise + auto-correlated "texture"
        % mu1
        mu1s_min = 10^(-1.0);
        mu1s_max = 10^(0.5);
        mu1s_n   = 7;
        % mu2
        mu2s_min = 10^(4.5);
        mu2s_max = 10^(6.0);
        mu2s_n   = 7; 
    case 4
        % settings for new decomposition examples
end
% compute the logarithmically-spaced (log10) mu1 and mu2 grid values
mu1s = unique(logspace(log10(mu1s_min),log10(mu1s_max),mu1s_n));
mu2s = unique(logspace(log10(mu2s_min),log10(mu2s_max),mu2s_n));
% if the just selected mu1s or mu2s contain a unique value, de-activate 
% (set to zero) the SHOW_PERFORMANCE_SURFACES flag variable, as the 
% surface degenerates to a point or segment (visually not interesting)
if ( ( numel(mu1s) == 1 ) || ( numel(mu2s) == 1 ) )
    SHOW_PERFORMANCE_SURFACES = 0;
end

% ----------------------------------------------------
% initialize/configure the ADMM-based numerical solver
    % initial guesses
        % primal variables (components c,g)
        c_0 = zeros(N,1);
        g_0 = zeros(N,1);
        % dual variables (Lagrange multipliers lambda_1,lambda_2)
        lambda_1_0 = zeros(N,1);
        lambda_2_0 = zeros(N,1);
        % penalty parameter beta
        beta_0 = 2;
    % stopping criteria
    k_max = 3000; % maximum number of iterations
    x_delta_tol = 1e-5; % tolerance for the x-relative change

% --------------------------------------------------
% allocate structures (matrices) where we will store
% all the (mu1,mu2)-dependent performance measures
if ( SHOW_PERFORMANCE_SURFACES == 1 )
    % 2D grids of mu1 and mu2 values
    [MU1S,MU2S] = meshgrid(mu1s,mu2s);
    % performance of the model: SNR values of the decompositions obtained
    C_SNRS     = zeros( size(MU1S) );
    S_SNRS     = zeros( size(MU1S) );
    O_SNRS     = zeros( size(MU1S) );
    CSO_SNRS   = zeros( size(MU1S) );
    % performance of the numerical solver
    ADMM_ITS   = zeros( size(MU1S) ); % number of performed iterations
    ADMM_XDELS = zeros( size(MU1S) ); % final x-relative changes x_delta
    ADMM_BETAS = zeros( size(MU1S) ); % final penalty parameter beta values    
end




% -------------------------------------------------------------------------
% cycle (solve the model) for all the above-selected (mu1,mu2) values
% -------------------------------------------------------------------------

% print a "header2 in the command window
fprintf('\nSOLVE THE  TV-TIK-G  VARIATIONAL DECOMPOSTION MODEL BY  ADMM');
fprintf('\nFOR A LOGARITHMICALLY-SPACED GRID OF %d x %d (mu_1,mu_2) VALUES:\n',mu1s_n,mu2s_n);

% intialize the "best" SNR values to a very low value
c_BEST_SNR   = -1e10;
s_BEST_SNR   = -1e10;
o_BEST_SNR   = -1e10;
cso_BEST_SNR = -1e10;

% cycle
for mu1_i = 1:mu1s_n
    % extract the current mu1 value
    mu1 = mu1s(mu1_i);
    for mu2_i = 1:mu2s_n
        % extract the current mu2 value
        mu2 = mu2s(mu2_i);
        % print in the command window
        fprintf('\nmu(%02d,%02d/%02d,%02d): ',mu1_i,mu2_i,mu1s_n,mu2s_n);
        
        % ------------------------------------------------------------------
        % for the current (mu1,mu2) values, solve the TV-TIK-G model by ADMM
        
            % OUTPUT VARIABLES
        [   c,g,s,o,           ... % estimated (minimized) primal variables (components c,g, then s,o) of the ADMM saddle-point problem
            lambda_1,lambda_2, ... % estimated (maximized) dual   variables (Lagrange multipliers)     of the ADMM saddle-point problem 
            beta,              ... % estimated (if self-adaptive strategy is used) ADMM penalty parameter
            k,x_delta,         ... % ADMM convergence: number of performed iterations and final x relative change
            monit ]            ... % structure where important quantities along ADMM iterations are stored
        = decompose_1D_sigs_into_cso_by_ADMM( ...
        ... % INPUT VARIABLES
            f,mu1,mu2,mu3,         ... % model data/parameters: observation and regularization parameters
            c_0,g_0,               ... % ADMM: initial guesses: dual variables
            lambda_1_0,lambda_2_0, ... % ADMM: initial guesses: primal variables
            beta_0,                ... % ADMM: penalty parameter (initial, if self-adaptive strategy is used) 
            1,       ... % flag variable (0=>NO,1=>YES): use self-adaptive strategy for beta
            k_max,x_delta_tol,     ... % ADMM stopping criteria: max number of iterations and tolerance for x relative change    
            0,              ... % flag variable (0=>NO,1=>YES): monitor/store/print/plot important quantities along ADMM iterations 
            0,  ... % flag variable (0=>NO,1=>YES): print some of the monitored quantities in the command window along ADMM iterations
            0,   ... % flag variable (0=>NO,1=>YES): plot the graphs of all the monitored quantities in the command window along ADMM iterations
            0,   ... % flag variable (0=>NO,1=>YES): show the estimated components c, s, o along the ADMM iterations
            0,   ... % flag variable (0=>NO,1=>YES): show all the monitored quantities (in graphs) at the end of ADMM iterations
            c_GT,s_GT,o_GT         ... % ground truth components (if available), so that we can also monitor SNR of decomposition
        );
    
        % --------------------------------------------------------------
        % compute the SNR values associated to the current decomposition
        c_SNR   = compute_snr(c,c_GT);
        s_SNR   = compute_snr(s,s_GT);
        o_SNR   = compute_snr(o,o_GT);
        cso_SNR = compute_snr([c;s;o],[c_GT;s_GT;o_GT]);
        SNRs    = [c_SNR,s_SNR,o_SNR,cso_SNR];
        
        % --------------------------------------------------------------------
        % print in the command window some of the current performance measures        
        fprintf('ITS %5d, x-d %.3e, SNR %7.3f %7.3f %7.3f => %7.3f',...
            k,x_delta,c_SNR,s_SNR,o_SNR,cso_SNR);
        
        % -------------------------------------------------------
        % check if the current SNR values are higher then the 
        % previous "best": if yes, store them as the new "best", 
        % and store also the mu1 and mu2 index values, and the
        % current estimated components
        if ( c_SNR > c_BEST_SNR )
            c_BEST_SNR = c_SNR; c_BEST_SNR_SNRs = SNRs;            
            c_BEST_SNR_mu1_i = mu1_i; c_BEST_SNR_mu2_i = mu2_i;
            c_BEST_SNR_c = c; c_BEST_SNR_s = s; c_BEST_SNR_o = o;
            c_BEST_SNR_k = k;
        end
        if ( s_SNR > s_BEST_SNR )
            s_BEST_SNR = s_SNR; s_BEST_SNR_SNRs = SNRs;            
            s_BEST_SNR_mu1_i = mu1_i; s_BEST_SNR_mu2_i = mu2_i;
            s_BEST_SNR_c = c; s_BEST_SNR_s = s; s_BEST_SNR_o = o;
            s_BEST_SNR_k = k;
        end
        if ( o_SNR > o_BEST_SNR )
            o_BEST_SNR = o_SNR; o_BEST_SNR_SNRs = SNRs;            
            o_BEST_SNR_mu1_i = mu1_i; o_BEST_SNR_mu2_i = mu2_i;
            o_BEST_SNR_c = c; o_BEST_SNR_s = s; o_BEST_SNR_o = o;
            o_BEST_SNR_k = k;
        end
        if ( cso_SNR > cso_BEST_SNR )
            cso_BEST_SNR = cso_SNR; cso_BEST_SNR_SNRs = SNRs;            
            cso_BEST_SNR_mu1_i = mu1_i; cso_BEST_SNR_mu2_i = mu2_i;
            cso_BEST_SNR_c = c; cso_BEST_SNR_s = s; cso_BEST_SNR_o = o;
            cso_BEST_SNR_k = k;
        end
        
        % --------------------------------------------------------------
        % store all the current (mu1,mu2)-dependent performance measures
        if ( SHOW_PERFORMANCE_SURFACES == 1 )
            % performance of the model: SNR values of the decompositions obtained
            C_SNRS(mu2_i,mu1_i)     = c_SNR;
            S_SNRS(mu2_i,mu1_i)     = s_SNR;
            O_SNRS(mu2_i,mu1_i)     = o_SNR;
            CSO_SNRS(mu2_i,mu1_i)   = cso_SNR;
            % performance of the numerical solver
            ADMM_ITS(mu2_i,mu1_i)   = k; % number of performed iterations
            ADMM_XDELS(mu2_i,mu1_i) = x_delta; % final x-relative changes x_delta
            ADMM_BETAS(mu2_i,mu1_i) = beta; % final penalty parameter beta values    
        end
               
        % ------------------------------
        % show the current decomposition
        if ( SHOW_CURRENT_DECOMPOSITION == 1 )
            fig_title = sprintf('mu_1(%02d/%02d) = %9.3e,   mu_2(%02d/%02d) = %9.3e :    ADMM ITS %05d,  SNRS  %7.4f %7.4f %7.4f  ==> %7.4f',...
                mu1_i,mu1s_n,mu1,mu2_i,mu2s_n,mu2,...
                k,c_SNR,s_SNR,o_SNR,cso_SNR);
            show_cso_decomposition( ...
                c,s,o,          ... % estimated components
                c_GT,s_GT,o_GT, ... % ground truth components
                2,              ... % number of the created Matlab figure
                fig_title,      ... % top/main title of the figure (sgtitle)
                SHOW_CURRENT_DECOMPOSITION_FULL_SCREEN, ... % flag variable (0=>NO,1=>YES): show the figure full-screen
                'r', ... % string specifying the line color and type for hat plots
                'b', ... % string specifying the line color and type for GT plots
                'r', ... % string specifying the line color and type for the observation f
                1,   ... % flag variable (0=>NO,1=>YES): show the hat plots
                1,   ... % flag variable (0=>NO,1=>YES): show the GT plots
                1    ... % flag variable (0=>NO,1=>YES): show the observation f in the top subplot
                ); 
        end
    end % end for mu2_i
end % end for mu1_i


% -------------------------------------------------------------------
% print in the command window the best decomposition results achieved
fprintf('\n\nBEST (SNR) DECOMPOSITION RESULTS :\n');

fprintf('\n%8s   %-45s',' ', '                BEST SNR for ...');
fprintf('\n%8s |%47s',' ','-----------------------------------------------');
fprintf('\n%8s | %-9s | %-9s | %-9s | %-9s',' ','    c','    s','    o','   cso');
fprintf('\n%9s|%11s|%11s|%11s|%11s','---------','-----------','-----------','-----------','-----------');

fprintf('\n%-8s | %9.3f | %9.3f | %9.3f | %9.3f','SNR(c)',c_BEST_SNR_SNRs(1),s_BEST_SNR_SNRs(1),o_BEST_SNR_SNRs(1),cso_BEST_SNR_SNRs(1));
fprintf('\n%9s|%11s|%11s|%11s|%11s','---------','-----------','-----------','-----------','-----------');

fprintf('\n%-8s | %9.3f | %9.3f | %9.3f | %9.3f','SNR(s)',c_BEST_SNR_SNRs(2),s_BEST_SNR_SNRs(2),o_BEST_SNR_SNRs(2),cso_BEST_SNR_SNRs(2));
fprintf('\n%9s|%11s|%11s|%11s|%11s','---------','-----------','-----------','-----------','-----------');

fprintf('\n%-8s | %9.3f | %9.3f | %9.3f | %9.3f','SNR(o)',c_BEST_SNR_SNRs(3),s_BEST_SNR_SNRs(3),o_BEST_SNR_SNRs(3),cso_BEST_SNR_SNRs(3));
fprintf('\n%9s|%11s|%11s|%11s|%11s','---------','-----------','-----------','-----------','-----------');

fprintf('\n%-8s | %9.3f | %9.3f | %9.3f | %9.3f','SNR(cso)',c_BEST_SNR_SNRs(4),s_BEST_SNR_SNRs(4),o_BEST_SNR_SNRs(4),cso_BEST_SNR_SNRs(4));
fprintf('\n%9s|%11s|%11s|%11s|%11s','---------','-----------','-----------','-----------','-----------');

fprintf('\n%-8s |   (%02d,%02d) |   (%02d,%02d) |   (%02d,%02d) |   (%02d,%02d)','mu12 ind',c_BEST_SNR_mu1_i,c_BEST_SNR_mu2_i,s_BEST_SNR_mu1_i,s_BEST_SNR_mu2_i,o_BEST_SNR_mu1_i,o_BEST_SNR_mu2_i,cso_BEST_SNR_mu1_i,cso_BEST_SNR_mu2_i);
fprintf('\n%9s|%11s|%11s|%11s|%11s','---------','-----------','-----------','-----------','-----------');

fprintf('\n%-8s | %9.3e | %9.3e | %9.3e | %9.3e','mu1',mu1s(c_BEST_SNR_mu1_i),mu1s(s_BEST_SNR_mu1_i),mu1s(o_BEST_SNR_mu1_i),mu1s(cso_BEST_SNR_mu1_i));
fprintf('\n%9s|%11s|%11s|%11s|%11s','---------','-----------','-----------','-----------','-----------');

fprintf('\n%-8s | %9.3e | %9.3e | %9.3e | %9.3e','mu2',mu2s(c_BEST_SNR_mu2_i),mu2s(s_BEST_SNR_mu2_i),mu2s(o_BEST_SNR_mu2_i),mu2s(cso_BEST_SNR_mu2_i));
fprintf('\n\n');

% -------------------------------------------------------------------
% show all performance surfaces, with domain (mu1,mu2) in log10-scale
if ( SHOW_PERFORMANCE_SURFACES == 1)
    
    % convert mu1s, mu2s arrays and MU1S, MU2S matrices to log10-scale
    log10_mu1s = log10(mu1s); log10_mu2s = log10(mu2s);
    log10_MU1S = log10(MU1S); log10_MU2S = log10(MU2S);
    
    % titles and xy labels font size
    font_size = 13;
    
    % figure 3: ADMM performance surfaces
    figure(3); 
    if ( SHOW_PERFORMANCE_SURFACES_FULL_SCREEN == 1 )
        set(gcf,'Position',get(0,'ScreenSize'));
    end
    
    % ADMM iterations surface
    subplot(2,2,1); hold off;
    surf(log10_MU1S,log10_MU2S,ADMM_ITS); 
    axis tight;
    xlabel('$\log_{10} \mu_1$','interpreter','latex','fontsize',font_size); 
    ylabel('$\log_{10} \mu_2$','interpreter','latex','fontsize',font_size); 
    title('$\mathrm{ADMM}\;\,\mathrm{CONVERGENCE:}\;\;\:\mathrm{NUMBER}\;\,\mathrm{of}\,\;\mathrm{PERFORMED}\;\mathrm{ITERATIONS}$','interpreter','latex','fontsize',font_size);
    
    % ADMM penalty parameter surface
    subplot(2,2,3); hold off;
    surf(log10_MU1S,log10_MU2S,ADMM_BETAS); 
    axis tight;
    xlabel('$\log_{10} \mu_1$','interpreter','latex','fontsize',font_size); 
    ylabel('$\log_{10} \mu_2$','interpreter','latex','fontsize',font_size); 
    title('$\mathrm{ADMM}\;\,\mathrm{CONVERGENCE:}\;\;\:\mathrm{PENALTY}\;\,\mathrm{PARAMETER}\;\;\beta$','interpreter','latex','fontsize',font_size);
    
    % ADMM x-relative change surface
    subplot(2,2,2); hold off;
    surf(log10_MU1S,log10_MU2S,ADMM_XDELS); 
    axis tight;
    xlabel('$\log_{10} \mu_1$','interpreter','latex','fontsize',font_size); 
    ylabel('$\log_{10} \mu_2$','interpreter','latex','fontsize',font_size); 
    title('$\mathrm{ADMM}\;\,\mathrm{CONVERGENCE:}\;\;\:x\mathrm{-RELATIVE}\;\,\mathrm{CHANGE}\;\;\delta_x$','interpreter','latex','fontsize',font_size);
    
    % figure 4: SNR surfaces for c, s, o, cso
        % parameters for drawing the BEST SNRs markers
        BEST_SNRs_marker_col     = 'r';
        BEST_SNRs_marker_size    = 50';
        cso_BEST_SNR_marker_col  = 'r';
        cso_BEST_SNR_marker_size = 50';
        
    figure(4); 
    if ( SHOW_PERFORMANCE_SURFACES_FULL_SCREEN == 1 )
        set(gcf,'Position',get(0,'ScreenSize'));
    end
    
    % SNR surface for c
    subplot(2,2,1); hold off;
    surf(log10_MU1S,log10_MU2S,C_SNRS); hold on;
    scatter3( log10_mu1s(c_BEST_SNR_mu1_i), ...
              log10_mu2s(c_BEST_SNR_mu2_i), ...
              C_SNRS(c_BEST_SNR_mu2_i,c_BEST_SNR_mu1_i), ...
              BEST_SNRs_marker_size,BEST_SNRs_marker_col,'filled');
    axis tight;
    xlabel('$\log_{10} \mu_1$','interpreter','latex','fontsize',font_size); 
    ylabel('$\log_{10} \mu_2$','interpreter','latex','fontsize',font_size); 
    title('$\mathrm{SNR}\;\;\mathrm{of}\;\;\widehat{c}\,(\mu_1,\mu_2)$','interpreter','latex','fontsize',font_size);
    
    % SNR surface for s
    subplot(2,2,2); hold off;
    surf(log10_MU1S,log10_MU2S,S_SNRS); hold on;
    scatter3( log10_mu1s(s_BEST_SNR_mu1_i), ...
              log10_mu2s(s_BEST_SNR_mu2_i), ...
              S_SNRS(s_BEST_SNR_mu2_i,s_BEST_SNR_mu1_i), ...
              BEST_SNRs_marker_size,BEST_SNRs_marker_col,'filled');
    axis tight;
    xlabel('$\log_{10} \mu_1$','interpreter','latex','fontsize',font_size);
    ylabel('$\log_{10} \mu_2$','interpreter','latex','fontsize',font_size);
    title('$\mathrm{SNR}\;\;\mathrm{of}\;\;\widehat{s}\,(\mu_1,\mu_2)$','interpreter','latex','fontsize',font_size);
    
    % SNR surface for o
    subplot(2,2,3); hold off;
    surf(log10_MU1S,log10_MU2S,O_SNRS); hold on;
    scatter3( log10_mu1s(o_BEST_SNR_mu1_i), ...
              log10_mu2s(o_BEST_SNR_mu2_i), ...
              O_SNRS(o_BEST_SNR_mu2_i,o_BEST_SNR_mu1_i), ...
              BEST_SNRs_marker_size,BEST_SNRs_marker_col,'filled');
    axis tight;
    xlabel('$\log_{10} \mu_1$','interpreter','latex','fontsize',font_size);
    ylabel('$\log_{10} \mu_2$','interpreter','latex','fontsize',font_size);
    title('$\mathrm{SNR}\;\;\mathrm{of}\;\;\widehat{o}\,(\mu_1,\mu_2)$','interpreter','latex','fontsize',font_size);
    
    % SNR surface for [c;s;o]
    subplot(2,2,4); hold off;
    surf(log10_MU1S,log10_MU2S,CSO_SNRS); hold on;
    scatter3( log10_mu1s(cso_BEST_SNR_mu1_i), ...
              log10_mu2s(cso_BEST_SNR_mu2_i), ...
              CSO_SNRS(cso_BEST_SNR_mu2_i,cso_BEST_SNR_mu1_i), ...
              cso_BEST_SNR_marker_size,cso_BEST_SNR_marker_col,'filled');
    axis tight;
    xlabel('$\log_{10} \mu_1$','interpreter','latex','fontsize',font_size);
    ylabel('$\log_{10} \mu_2$','interpreter','latex','fontsize',font_size);
    title('$\mathrm{SNR}\;\;\mathrm{of}\;\;[\,\widehat{c};\widehat{s};\widehat{o}\,]\,(\mu_1,\mu_2)$','interpreter','latex','fontsize',font_size);
end

% ------------------------------------
% show the best decomposition achieved
if ( SHOW_BEST_SNR_DECOMPOSITION == 1 )
    fig_title = sprintf('BEST SNR:   mu_1(%02d/%02d) = %9.3e,   mu_2(%02d/%02d) = %9.3e :    ADMM ITS %05d,  SNRS  %7.4f %7.4f %7.4f  ==> %7.4f',...
        cso_BEST_SNR_mu1_i,mu1s_n,mu1s(cso_BEST_SNR_mu1_i),...
        cso_BEST_SNR_mu2_i,mu2s_n,mu2s(cso_BEST_SNR_mu2_i),...
        cso_BEST_SNR_k,cso_BEST_SNR_SNRs);
    show_cso_decomposition( ...
        cso_BEST_SNR_c,cso_BEST_SNR_s,cso_BEST_SNR_o, ... % estimated components
        c_GT,s_GT,o_GT, ... % ground truth components
        5,              ... % number of the created Matlab figure
        fig_title,      ... % top/main title of the figure (sgtitle)
        SHOW_BEST_SNR_DECOMPOSITION_FULL_SCREEN, ... % flag variable (0=>NO,1=>YES): show the figure full-screen
        'r', ... % string specifying the line color and type for hat plots
        'b', ... % string specifying the line color and type for GT plots
        'r', ... % string specifying the line color and type for the observation f
        1,   ... % flag variable (0=>NO,1=>YES): show the hat plots
        1,   ... % flag variable (0=>NO,1=>YES): show the GT plots
        1    ... % flag variable (0=>NO,1=>YES): show the observation f in the top subplot
        );
end





