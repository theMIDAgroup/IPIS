% -------------------------------------------------------------------------
% PRIN2022 "Inverse Problems in the Imaging Sciences (IPIS)"
% UNIT UNIBO (University of Bologna):
% Serena Morigi, Damiana Lazzaro, Alessandro Lanza
% -------------------------------------------------------------------------
%
% -------------------------------------------------------------------------
% INVERSE PROBLEM:
% This Matlab code is aimed to decompose a 1D signal f into
% the sum of three morphologically different components:
%
% f = c + s + o
%
% where
%
% c => piecewise constant component
% s => smooth component (trend)
% o => highly oscillatory component
% 
% The highly oscillatory component can include white (or, more 
% in general, i.i.d) noise signals and/or "texture", i.e. 
% auto-correlated (non-white, colored) mid-high-frequency signals.

% -------------------------------------------------------------------------
% VARIATIONAL MODEL:
% The decomposition is obtained based on the Predictor stage in [1], 
% i.e. on solving the linearly constrained, convex, non-differentiable 
% three-terms variational model oulined in equations (3)-(4) in [1]. 
%
% [1] L. Girometti, M. Huska, A. Lanza, S. Morigi, 
%     Convex Predictor–Nonconvex Corrector Optimization Strategy 
%     with Application to Signal Decomposition, 
%     Journal of Optimization Theory and Applications, vol.202, pp.1286-1325, 2024.
%
% The three terms are suitably designed to capture the different 
% morphologies of the three components c, s, o to separate. The model, 
% when applied to decomposing an observed N-samples 1D signal f reads:
%
% {c_hat,s_hat,o_hat} in argmin J(c,s,o;mu1,mu2,mu3) , 
%                        c,s,o
%
% subject to:  c + s + o = f , sum_i c_i = 0 (c is zero-mean) ,
%
% and with:  J(c,s,o;mu1,mu2,mu3) =    mu1    || Dc ||_1   (TV semi-norm)
%                                   + (mu2/2) || Hs ||_2^2 (TIK norm)
%                                   +  mu3    || o ||_G    (Meyer's G-norm),
%
% with mu1, m2, mu3 > 0 free regularization parameters, D and H two N x N 
% finite difference matrices discretizing the 1st- and 2nd-order derivative 
% operators, respectively. The G-norm reads 
%
% ||o||_G = inf { ||g||_oo | o = DT g } .
%            g
%
% In [1] (Section 4), the model is then equivalently and usefully 
% reformulated (the problem dimensionality decreases from 4N to 2N) as:
%
% {c_hat,g_hat} in argmin_{c,g} J(c,g;mu1,mu2,mu3) , 
%                   c,g
%
% subject to:  sum_i c_i = 0 (c is zero-mean) ,
%
% and with:  J(c,g;mu1,mu2,mu3) =    mu1    || Dc ||_1   
%                                 + (mu2/2) ||H(c + DT g - f)||_2^2
%                                 +  mu3    || g ||_oo ,
%
% Once a solution {c_hat,g_hat} is computed, the associated estimated 
% components s_hat and o_hat are simply obtained applying the formulas:
%
% o_hat = DT g_hat , s_hat = f - c_hat - o_hat .

% -------------------------------------------------------------------------
% NUMERICAL SOLVER:
% The reduced variational model is efficiently solved based on a suitable
% 2-blocks ADMM-based iterative algorithm (see Section 5 in [1]), equipped 
% with an effective self-adaptive strategy for the ADMM penalty parameter, 
% aimed to improve the convergence behaviour.

% -------------------------------------------------------------------------
% IMPORTANT REMARKS:
% (1) In the ADMM-based solver, the mimization sub-problem for the primal 
%     variable z_1 is a 1D TV-l2 denosing problem. For efficiency, and 
%     coherently with what is declared in [1], this problem is solved 
%     exactly in finite-time by means of the O(N) approach proposed by 
%     L. Condat in [2].
%      
%     [2] L. Condat, A direct algorithm for 1-D total variation denoising,
%         IEEE Signal Processing Letters, vol.20(11), pp.1054–1057, 2013.
%
%     In particular, we used the C-implementation of the algorithm made
%     available by the author ( --> https://lcondat.github.io/software.html , 
%     hyperlink "mex" in the sentence "For use in Matlab, mex files made 
%     by Stephen Becker" ). 
% (2) Both in this script and in the function "decompose_1D_sigs_into_cso_by_ADMM", 
%     which implements the ADMM-based solver, the implementation is totally 
%     coherent with [1]: in terms of variational model, of minimization
%     algorithm and of names of variables. The only exception concerns the 
%     regularization parameters: in [1] we have gamma_1 and gamma_2 as the
%     regularization parameters for the c and s terms, while the last term 
%     for variable g is multiplied by 1. In this implementation, we call 
%     the first two parameters mu1 and mu2, and we use also a third
%     parameter mu3 in front of the last term (but we set it equal to 1). 
% (3) To evaluate effectiveness of the variational model modulo the values 
%     of the regularization parameters mu1, mu2, m3, first we fix mu3 to a  
%     constant value (which clearly does not exclude any possible solution 
%     of the model), then we run the model/algorithm for a uniform rectangular 
%     grid of (mu1,m2) values (in logarithmic scale), we collect the SNR 
%     values associated to all the decompositions obtained, and finally 
%     call the "model result" the "best" decomposition achieved, associated 
%     to the highest SNR value.
% (4) Three test decomposition examples are placed (as binary Matlab files 
%     .mat) in the folder "./input/"; one can choose which example to load 
%     and test by setting the variable example_id (= 1,2,3) on the top of 
%     the file "generate_decomposition_example.m", which is called at line 
%     162 of this main script.
%
% REMARK: 
% The first time you run this code on a computer, uncomment the following 
% instruction, so that you mex-compile (once for all) the C-code 
% "TV1D_denoise_mex.c" (which is in the same directory of this script), 
% and you obtain (in the same directory) the C-compiled file 
% "TV1D_denoise_mex.mexw64". This compiled file is used for the 
% efficient solution of one of the minimization sub-problems of
% the ADMM-based numerical solver used in this code. The C-code 
% "TV1D_denoise_mex.c" has been written and made available by L. Condat 
% (and S. Becker). See REMARK (1) below for more details.
% Once you compile successfully the file, comment the instruction below 
% to avoid re-compiling every time you run this script. If you have 
% problems in compiling, change the instruction (add -v option) into:
% mex -v TV1D_denoise_mex.c -largeArrayDims
% In this way, you will perform a "verbose" compiling, so that you will 
% obtain information (debug) on every step of the compiling process.

mex TV1D_denoise_mex.c -largeArrayDims